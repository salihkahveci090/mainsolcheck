import json
import logging
import os
import platform
import secrets
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from itertools import product
from math import ceil
from multiprocessing.pool import Pool

import pyopencl as cl

os.environ["PYOPENCL_COMPILER_OUTPUT"] = "1"
os.environ["PYOPENCL_NO_CACHE"] = "TRUE"
from pathlib import Path

import click
import numpy as np
from base58 import b58decode, b58encode
from nacl.signing import SigningKey

logging.basicConfig(level="INFO", format="[%(levelname)s %(asctime)s] %(message)s")


class HostSetting:
    def __init__(self, kernel_source: str, iteration_bits: int) -> None:
        self.iteration_bits = iteration_bits
        self.iteration_bytes = np.ubyte(ceil(iteration_bits / 8))
        self.global_work_size = 1 << iteration_bits
        self.local_work_size = 32
        self.key32 = self.generate_key32()

        self.kernel_source = kernel_source

    def generate_key32(self):
        token_bytes = (
            secrets.token_bytes(32 - self.iteration_bytes)
            + b"\x00" * self.iteration_bytes
        )
        key32 = np.array([x for x in token_bytes], dtype=np.ubyte)
        return key32

    def increase_key32(self):
        current_number = int(bytes(self.key32).hex(), base=16)
        next_number = current_number + (1 << self.iteration_bits)
        _number_bytes = next_number.to_bytes(32, "big")
        new_key32 = np.array([x for x in _number_bytes], dtype=np.ubyte)
        carry_index = 0 - self.iteration_bytes
        if (new_key32[carry_index] < self.key32[carry_index]) and new_key32[
            carry_index
        ] != 0:
            new_key32[carry_index] = 0

        self.key32[:] = new_key32


def check_character(name: str, character: str):
    try:
        b58decode(character)
    except ValueError as e:
        logging.error(f"{str(e)} in {name}")
        sys.exit(1)
    except Exception as e:
        raise e


def get_kernel_source(starts_with: str, ends_with: str, cl):
    PREFIX_BYTES = list(bytes(starts_with.encode()))
    SUFFIX_BYTES = list(bytes(ends_with.encode()))

    with open(Path("opencl/kernel.cl"), "r") as f:
        source_lines = f.readlines()

    for i, s in enumerate(source_lines):
        if s.startswith("constant uchar PREFIX[]"):
            source_lines[i] = (
                f"constant uchar PREFIX[] = {{{', '.join(map(str, PREFIX_BYTES))}}};\n"
            )
        if s.startswith("constant uchar SUFFIX[]"):
            source_lines[i] = (
                f"constant uchar SUFFIX[] = {{{', '.join(map(str, SUFFIX_BYTES))}}};\n"
            )

    source_str = "".join(source_lines)

    if "NVIDIA" in str(cl.get_platforms()) and platform.system() == "Windows":
        source_str = source_str.replace("#define __generic\n", "")

    if cl.get_cl_header_version()[0] != 1 and platform.system() != "Windows":
        source_str = source_str.replace("#define __generic\n", "")

    return source_str


def get_all_gpu_devices():
    devices = [
        device
        for platform in cl.get_platforms()
        for device in platform.get_devices(device_type=cl.device_type.GPU)
    ]
    return [d.int_ptr for d in devices]


def save_result(outputs, output_dir, line=None):
    result_count = 0
    result_file = Path(output_dir, "results.txt")
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    with result_file.open("a") as f:
        for output in outputs:
            if not output[0]:
                continue
            result_count += 1
            pv_bytes = bytes(output[1:])
            pv = SigningKey(pv_bytes)
            pb_bytes = bytes(pv.verify_key)
            pubkey = b58encode(pb_bytes).decode()
            combined_bytes = pv_bytes + pb_bytes
            base58_encoded = b58encode(combined_bytes).decode()
            
            if line:
                original_address = line.split(':')[0]
                receive_address = line.split(':')[1].strip()  # ":" sonrası adresi al
                f.write(f"Adres: {original_address} -- Üretilen Adres: {pubkey} -- Private Key: {base58_encoded} -- Receive Adres: {receive_address}\n")
            
            logging.info(f"Base58 Encoded: {base58_encoded}")
            logging.info(f"Found: {pubkey}")
            
    return result_count


class Searcher:
    def __init__(self, *, kernel_source, index: int, setting: HostSetting, context=None):
        device_ids = get_all_gpu_devices()
        if context:
            self.context = context
            self.gpu_chunks = 1
        else:
            self.context = cl.Context([cl.Device.from_int_ptr(device_ids[index])])
            self.gpu_chunks = len(device_ids)
        self.command_queue = cl.CommandQueue(self.context)

        self.setting = setting
        self.index = index
        program = cl.Program(self.context, kernel_source).build()
        self.program = program
        self.kernel = cl.Kernel(program, "generate_pubkey")

    def find(self):
        memobj_key32 = cl.Buffer(
            self.context,
            cl.mem_flags.READ_ONLY | cl.mem_flags.COPY_HOST_PTR,
            32 * np.ubyte().itemsize,
            hostbuf=self.setting.key32,
        )
        memobj_output = cl.Buffer(
            self.context, cl.mem_flags.READ_WRITE, 33 * np.ubyte().itemsize
        )
        memobj_occupied_bytes = cl.Buffer(
            self.context,
            cl.mem_flags.READ_WRITE | cl.mem_flags.COPY_HOST_PTR,
            hostbuf=np.array([self.setting.iteration_bytes]),
        )
        memobj_group_offset = cl.Buffer(
            self.context,
            cl.mem_flags.READ_WRITE | cl.mem_flags.COPY_HOST_PTR,
            hostbuf=np.array([self.index]),
        )
        output = np.zeros(33, dtype=np.ubyte)
        self.kernel.set_arg(0, memobj_key32)
        self.kernel.set_arg(1, memobj_output)
        self.kernel.set_arg(2, memobj_occupied_bytes)
        self.kernel.set_arg(3, memobj_group_offset)

        st = time.time()
        global_worker_size = self.setting.global_work_size // self.gpu_chunks
        cl.enqueue_nd_range_kernel(
            self.command_queue,
            self.kernel,
            (global_worker_size,),
            (self.setting.local_work_size,),
        )
        cl._enqueue_read_buffer(self.command_queue, memobj_output, output).wait()
        logging.info(f"GPU {self.index} Speed: {global_worker_size/ ((time.time() - st) * 10**6):.2f} MH/s")
        return output

def multi_gpu_init(index, setting):
    # Kernel işlemini başlat ve sonuçları döndür
    searcher = Searcher(kernel_source=setting.kernel_source, index=index, setting=setting)
    result = searcher.find()  # Burada result tek bir değer veya liste olabilir
    if isinstance(result, list):
        return result  # Eğer bir liste döndürüldüyse, bu listeyi döndür
    else:
        return [result]  # Eğer tek bir sonuç döndürüldüyse, bunu liste içine alarak döndür
        
@click.group()
def cli():
    pass


@cli.command(context_settings={"show_default": True})
@click.option(
    "--pattern-file",
    type=click.Path(exists=True),
    help="Path to the file with the list of addresses to process.",
)
@click.option(
    "--output-dir",
    type=click.Path(file_okay=False, dir_okay=True, writable=True),
    help="Output directory.",
    default="./",
)
@click.option(
    "--iteration-bits",
    type=int,
    help="Number of the iteration occupied bits. Recommended 24, 26, 28, 30, 32.",
    default=24,
)
@click.pass_context
def search_pubkey(
    ctx,
    pattern_file: str,
    output_dir: str,
    iteration_bits: int,
):
    """Search Solana vanity pubkey"""

    # Read addresses from file
    with open(pattern_file, 'r') as f:
        lines = f.readlines()

    # Check already processed addresses
    processed_addresses = set()
    result_count = 0

    # Read the processed addresses from result.txt to avoid reprocessing
    result_file = Path(output_dir, "results.txt")
    if result_file.exists():
        with open(result_file, 'r') as f:
            for line in f:
                # Parse out the address part from the result line
                address = line.split(" -- ")[0].split(":")[1].strip()
                processed_addresses.add(address)

    while len(processed_addresses) < len(lines):
        for line in lines:
            address = line.split(":")[0]
            
            if address in processed_addresses:
                continue  # Skip already processed addresses

            starts_with = address[:4]  # First 4 characters
            ends_with = address[-1]   # Last character
            logging.info(f"Searching for pubkey starting with {starts_with} and ending with {ends_with}")

            kernel_source = get_kernel_source(starts_with, ends_with, cl)
            setting = HostSetting(kernel_source, iteration_bits)

            # Perform search and save result if found
            result = multi_gpu_init(0, setting)
            if result:
                result_count += save_result(
                    outputs=result, output_dir=output_dir, line=line
                )

                # Mark the current address as processed
                processed_addresses.add(address)

        # After going through all lines, return to the beginning to check unprocessed addresses
        logging.info("Re-checking remaining addresses...")

    logging.info(f"Total results found: {result_count}")
    logging.info(f"Results written to {output_dir}/results.txt")

if __name__ == "__main__":
    cli()